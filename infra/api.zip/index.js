"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  lambdaHandler: () => lambdaHandler
});
module.exports = __toCommonJS(src_exports);
var import_postgres_migrations = require("../node_modules/postgres-migrations/dist/index.js");
var import_pg = __toESM(require("../node_modules/pg/lib/index.js"));
var lambdaHandler = async (event, context) => {
  console.log(`Event: ${JSON.stringify(event, null, 2)}`);
  console.log(`Context: ${JSON.stringify(context, null, 2)}`);
  const { DB_HOST, DB_PASSWORD, DB_USERNAME } = process.env;
  const dbConfig = {
    database: "main",
    user: DB_USERNAME,
    password: DB_PASSWORD,
    host: DB_HOST,
    port: 5432,
    ensureDatabaseExists: true
  };
  const client = new import_pg.default.Client(dbConfig);
  await client.connect();
  try {
    await (0, import_postgres_migrations.migrate)({ client }, "./migrations");
  } finally {
    await client.end();
  }
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: "Much pipeline."
    })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  lambdaHandler
});
